import { motion } from 'framer-motion';
import { useLang } from '../i18n/LanguageContext';
import { IconMonitor, IconPenTool, IconRocket, IconSettings, IconArrowRight } from './Icons';

export default function Services() {
  const { t } = useLang();

  const services = [
    {
      title: t('services.web.title'),
      description: t('services.web.desc'),
      icon: <IconMonitor className="w-8 h-8" />,
      rune: 'ᚠ',
      features: [t('services.web.f1'), t('services.web.f2'), t('services.web.f3'), t('services.web.f4')],
      gradient: 'from-purple-500/20 to-violet-500/5',
      borderColor: 'hover:border-purple-500/40',
      glowColor: 'group-hover:shadow-purple-500/10',
      iconColor: 'text-purple-400',
    },
    {
      title: t('services.ui.title'),
      description: t('services.ui.desc'),
      icon: <IconPenTool className="w-8 h-8" />,
      rune: 'ᚢ',
      features: [t('services.ui.f1'), t('services.ui.f2'), t('services.ui.f3'), t('services.ui.f4')],
      gradient: 'from-cyan-500/20 to-teal-500/5',
      borderColor: 'hover:border-cyan-500/40',
      glowColor: 'group-hover:shadow-cyan-500/10',
      iconColor: 'text-cyan-400',
    },
    {
      title: t('services.landing.title'),
      description: t('services.landing.desc'),
      icon: <IconRocket className="w-8 h-8" />,
      rune: 'ᚦ',
      features: [t('services.landing.f1'), t('services.landing.f2'), t('services.landing.f3'), t('services.landing.f4')],
      gradient: 'from-pink-500/20 to-rose-500/5',
      borderColor: 'hover:border-pink-500/40',
      glowColor: 'group-hover:shadow-pink-500/10',
      iconColor: 'text-pink-400',
    },
    {
      title: t('services.custom.title'),
      description: t('services.custom.desc'),
      icon: <IconSettings className="w-8 h-8" />,
      rune: 'ᚨ',
      features: [t('services.custom.f1'), t('services.custom.f2'), t('services.custom.f3'), t('services.custom.f4')],
      gradient: 'from-blue-500/20 to-indigo-500/5',
      borderColor: 'hover:border-blue-500/40',
      glowColor: 'group-hover:shadow-blue-500/10',
      iconColor: 'text-blue-400',
    },
  ];

  return (
    <section id="services" className="relative py-32 px-4 overflow-hidden">
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-pink-600/3 rounded-full blur-[200px]" />
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-purple-600/5 rounded-full blur-[180px]" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-pink-400/40 text-sm tracking-[0.5em] uppercase font-[Cinzel] block mb-4">
            — {t('services.section')} —
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-[Cinzel_Decorative] gradient-text mb-4">
            {t('services.title')}
          </h2>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto">{t('services.subtitle')}</p>
          <div className="flex items-center justify-center gap-4 mt-6">
            <div className="w-16 h-px bg-gradient-to-r from-transparent to-pink-500/50" />
            <span className="text-pink-500/30 rune-text text-sm">ᚷ</span>
            <div className="w-16 h-px bg-gradient-to-l from-transparent to-pink-500/50" />
          </div>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              className={`group relative glass rounded-2xl p-8 border border-gray-800/50 ${service.borderColor} transition-all duration-500 hover:shadow-2xl ${service.glowColor} overflow-hidden`}
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.12 }}
              whileHover={{ y: -5 }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-700`} />
              <motion.span
                className="absolute top-4 right-6 text-4xl rune-text text-purple-500/8 group-hover:text-purple-500/15 transition-all duration-500 select-none"
                animate={{ y: [-3, 3, -3] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                {service.rune}
              </motion.span>

              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-5">
                  <span className={`${service.iconColor} group-hover:scale-110 transition-transform duration-500`}>
                    {service.icon}
                  </span>
                  <h3 className="text-xl font-bold font-[Cinzel] text-gray-100 group-hover:text-white transition-colors">
                    {service.title}
                  </h3>
                </div>
                <p className="text-gray-400 mb-6 leading-relaxed text-sm">{service.description}</p>
                <div className="grid grid-cols-2 gap-2">
                  {service.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-2 text-xs text-gray-500 group-hover:text-gray-400 transition-colors">
                      <svg className="w-3 h-3 text-purple-500/50 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                      {feature}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <p className="text-gray-500 mb-6 text-sm">{t('services.cta.text')}</p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-purple-600/20 to-cyan-600/20 border border-purple-500/25 rounded-xl text-purple-300 font-medium hover:from-purple-600/30 hover:to-cyan-600/30 hover:border-purple-400/40 transition-all duration-500 hover:shadow-lg hover:shadow-purple-500/10"
          >
            <span>{t('services.cta.button')}</span>
            <IconArrowRight className="w-4 h-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
